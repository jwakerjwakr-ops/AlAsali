package com.alasali.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Black = Color(0xFF101010)
private val Panel = Color(0xFF1B1B1B)
private val Gold = Color(0xFFD5AA4B)
private val Muted = Color(0xFFB9B1A1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlAsaliApp() }
    }
}

@Composable
fun AlAsaliApp() {
    var activated by remember { mutableStateOf(false) }
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var page by remember { mutableStateOf("home") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Black, surface = Panel,
        onPrimary = Black, onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Black) {
            if (!activated) {
                ActivationScreen(
                    code = code,
                    onCodeChange = { code = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(16); error = "" },
                    error = error,
                    onActivate = {
                        error = if (code.length != 16) "أدخل كوداً من 16 خانة." else
                            "التفعيل غير متصل بالخادم بعد. هذه نسخة واجهة أولية."
                    }
                )
            } else {
                HomeScreen(page = page, onPage = { page = it })
            }
        }
    }
}

@Composable
private fun BrandHeader() {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Text("العسلي", color = Gold, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
        Text("AL ASALI", color = Muted, fontSize = 11.sp, letterSpacing = 4.sp)
    }
}

@Composable
private fun ActivationScreen(
    code: String, onCodeChange: (String) -> Unit, error: String, onActivate: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        BrandHeader()
        Spacer(Modifier.height(42.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("تفعيل الاشتراك", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("أدخل كود التفعيل الذي حصلت عليه من الإدارة", color = Muted, fontSize = 14.sp)
                OutlinedTextField(
                    value = code, onValueChange = onCodeChange, singleLine = true,
                    label = { Text("كود التفعيل") }, placeholder = { Text("16 خانة") },
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Characters,
                        keyboardType = KeyboardType.Ascii
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Gold, focusedLabelColor = Gold,
                        cursorColor = Gold, unfocusedBorderColor = Color.DarkGray
                    ), modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = onActivate, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) {
                    Text("تفعيل", fontWeight = FontWeight.Bold)
                }
                if (error.isNotBlank()) Text(error, color = Color(0xFFFFC36B), fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("نسخة تأسيسية — التحقق الفعلي من الأكواد يحتاج ربط الخادم", color = Muted,
            fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun HomeScreen(page: String, onPage: (String) -> Unit) {
    val sections = listOf("جواكر", "بلياردو", "سوليتير", "اشتراكي", "الدعم", "اللغة")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        BrandHeader()
        Spacer(Modifier.height(24.dp))
        Text(if (page == "home") "الرئيسية" else page, color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("أهلاً بك في العسلي", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("اختر القسم الذي تريد فتحه", color = Muted, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        sections.forEach { item ->
            Card(
                onClick = { onPage(item) },
                colors = CardDefaults.cardColors(containerColor = Panel),
                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                    .border(1.dp, Gold.copy(alpha = .35f), RoundedCornerShape(14.dp)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(item, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Text("‹", color = Gold, fontSize = 24.sp)
                }
            }
        }
        if (page != "home") {
            Spacer(Modifier.height(12.dp))
            Text("قسم $page — سيتم ربط وظيفته بعد استكمال تحليل النسخة الأصلية.",
                color = Muted, fontSize = 13.sp)
            OutlinedButton(onClick = { onPage("home") }) { Text("العودة للرئيسية", color = Gold) }
        }
    }
}
